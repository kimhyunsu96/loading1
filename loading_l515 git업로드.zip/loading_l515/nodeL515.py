import os
import pyrealsense2 as rs
import numpy as np
import cv2
import datetime
import time
import easyocr

from PyQt5.QtCore import Qt, pyqtSignal, QObject, QThread
from realsense_device_manager import DeviceManager

# Define some constants
L515_resolution_width = 1024  # pixels
L515_resolution_height = 768  # pixels
L515_frame_rate = 30

# Define some constants
resolution_width = 1280  # pixels
resolution_height = 720  # pixels
frame_rate = 30  # fps

dispose_frames_for_stablisation = 30  # frames

class SensorSignal(QObject):
    color_signal = pyqtSignal(np.ndarray,int)
    color_signal2 = pyqtSignal(np.ndarray,int)
    depth_signal = pyqtSignal(np.ndarray,int)
    depth_signal2 = pyqtSignal(np.ndarray,int)

class dSensor(QThread):
    
    def __init__(self, parent=None):
        super(self.__class__, self).__init__(parent)
        self.dssg = SensorSignal()
        self.flag_CamON = False #카메라 ON
        self.set_up()
        self.targetD = 0
        self.thickness = 0

        self.depth_flag = False
        self.img_save_flag = False
        self.avi_aave_falg = False
        self.device_num = None

        print('dsensor init*')

    # 카메라 세팅 작업
    def set_up(self):
        try:
            # Enable the streams from all the intel realsense devices
            L515_rs_config = rs.config()
            L515_rs_config.enable_stream(rs.stream.depth, L515_resolution_width, L515_resolution_height, rs.format.z16,
                                         L515_frame_rate)
            L515_rs_config.enable_stream(rs.stream.infrared, 0, L515_resolution_width, L515_resolution_height, rs.format.y8,
                                         L515_frame_rate)
            L515_rs_config.enable_stream(rs.stream.color, resolution_width, resolution_height, rs.format.bgr8, frame_rate)

            rs_config = rs.config()
            rs_config.enable_stream(rs.stream.depth, resolution_width, resolution_height, rs.format.z16, frame_rate)
            rs_config.enable_stream(rs.stream.infrared, 1, resolution_width, resolution_height, rs.format.y8, frame_rate)
            rs_config.enable_stream(rs.stream.color, resolution_width, resolution_height, rs.format.bgr8, frame_rate)

            # Processing blocks
            self.pc = rs.pointcloud()

            # Use the device manager class to enable the devices and get the frames
            self.device_manager = DeviceManager(rs.context(), rs_config, L515_rs_config)
            self.device_manager.enable_all_devices()
        except KeyboardInterrupt:
            print("The program was interupted by the user. Closing the program...")

    def imageProcessing(self, adFrame, crFrame):
        depth_align = np.asanyarray(adFrame.get_data())
        color_image = np.asanyarray(crFrame.get_data())
        depth_colormap = cv2.applyColorMap(cv2.convertScaleAbs(depth_align, alpha=0.05), cv2.COLORMAP_JET)
        depthZ_img = depth_align.copy()
        lower_z = np.array([self.targetD])
        upper_z = np.array([self.targetD + self.thickness])
        maskZ_img = cv2.inRange(depthZ_img, lower_z, upper_z)

        return maskZ_img

    def setTargetD(self, d):
        self.targetD = d
        print(self.targetD)

    def setThickness(self, t):
        self.thickness = t

    # main Thread 시작
    def run(self):
        print("cam start")
        self.flag_CamON = True

        # Processing blocks
        pc = rs.pointcloud()
        frame_idx = 0
        f_no = 1

        while self.flag_CamON:
            frames = self.device_manager.poll_frames()

            Num_cam = 1
            cam_no1 = {}
            cam_no2 = {}


            for (device, frame) in frames.items():

                if self.device_num is None :
                    self.device_num = device
#                pc.map_to(frame[rs.stream.color])
#               points = pc.calculate(frame[rs.stream.depth])

                color_frame = frame[rs.stream.color]
                depth_frame = frame[rs.stream.depth]
                color_image = np.asarray(frame[rs.stream.color].get_data())
                depth_image = np.asarray(frame[rs.stream.depth].get_data())

                cur_dir = str(os.getcwd())
                img_date = datetime.datetime.now().strftime("%Y%m%d")
                date_dir = cur_dir + "/img/" + img_date
                avi_dir = cur_dir + "/avi/" + img_date

                if not os.path.exists(date_dir):
                    os.mkdir(date_dir)

                if not os.path.exists(avi_dir):
                    os.mkdir(avi_dir)


                ftIName = str(f_no) + '.png'

                if self.device_num == device:
                    if frame_idx % 6 == 0 :
                        if self.depth_flag:
                            color_image = self.imageProcessing(color_frame, depth_frame)
                            color_image = cv2.cvtColor(color_image, cv2.COLOR_GRAY2RGB)

                        if self.img_save_flag :
                            cam_no1_dir = date_dir + "/cam_no1"
                            if not os.path.exists(cam_no1_dir):
                                os.mkdir(cam_no1_dir)
                            no1_dir = cam_no1_dir
                            cv2.imwrite(os.path.join(no1_dir, ftIName), color_image)

                        self.dssg.color_signal.emit(color_image,1)
                    #cam_no1['color'] = color_image
                    #cam_no1['depth'] = depth_image
                else:
                    if frame_idx % 6 == 0:
                        if self.depth_flag:
                            color_image = self.imageProcessing(color_frame, depth_frame)
                            color_image = cv2.cvtColor(color_image, cv2.COLOR_GRAY2RGB)

                        if self.img_save_flag :
                            cam_no2_dir = date_dir + "/cam_no2"
                            if not os.path.exists(cam_no2_dir):
                                os.mkdir(cam_no2_dir)
                            no2_dir = cam_no2_dir
                            cv2.imwrite(os.path.join(no2_dir, ftIName), color_image)

                        self.dssg.color_signal2.emit(color_image,2)
 
                    #cam_no2['color'] = color_image
                    #cam_no2['depth'] = depth_image
                f_no += 1





            frame_idx += 1
            #time.sleep(1)
            #self.visualise_measurements(frames)

    #종료
    def stop(self):
        self.flag_CamON = False
        self.device_manager.disable_streams()

    def easy_ocr(self):
        reader = easyocr.Reader(['ko', 'en'], gpu=True)
        result = reader.readtext('test.png')
        img = cv2.imread('test.png')
        pass
