import os
from PyQt5 import QtGui
from PyQt5.QtCore import QDir, Qt
from PyQt5.QtGui import QImage, QPainter, QPalette, QPixmap, qRgb
from PyQt5.QtWidgets import (QAction, QApplication, QFileDialog, QLabel,
                             QMainWindow, QMenu, QMessageBox, QScrollArea, QSizePolicy, QInputDialog)
from PyQt5.QtPrintSupport import QPrintDialog, QPrinter
from PyQt5.QtCore import pyqtSignal, pyqtSlot, Qt, QThread, QRect
from PyQt5.QtWidgets import QWidget, QApplication, QLabel, QGridLayout, QCheckBox, QInputDialog, QVBoxLayout, QHBoxLayout, \
    QGroupBox, QLineEdit, QPushButton, QTextEdit, QComboBox, QSlider
from PyQt5.QtGui import QPixmap, QImage, QColor

import numpy as np
import nodeL515
import cv2


class ImageViewer(QMainWindow):

    def __init__(self):
        super(ImageViewer, self).__init__()

        self.nodeL515 = nodeL515.dSensor()
        self.connectSignal()

        self.width = 1920
        self.height = 1024


        # Add the completeted layout to the window
        self.centralWidget = QWidget()
        self.setCentralWidget(self.centralWidget)

        self.imageLabel = QLabel()
        self.imageLabel.setPixmap(QtGui.QPixmap("c.jpg"))
        self.imageLabel.setWordWrap(False)
        self.imageLabel.setGeometry(QRect(0, 0, 640, 480))
        self.imageLabel.setObjectName("image_label")

        self.imageLabel_2 = QLabel()
        self.imageLabel_2.setPixmap(QtGui.QPixmap("c.jpg"))
        self.imageLabel_2.setWordWrap(False)
        self.imageLabel_2.setGeometry(QRect(0, 0, 640, 480))
        self.imageLabel_2.setObjectName("image_label2")

        whole_box = QVBoxLayout()

        img_box = QVBoxLayout()
        img_box.addWidget(self.imageLabel)
        img_box.addWidget(self.imageLabel_2)

        whole_box.addLayout(self.buttonUI())
        whole_box.addLayout(img_box)


        self.centralWidget.setLayout(whole_box)

        self.setWindowTitle("Image Viewer")
        self.show()
        self.nodeL515.start()

    def buttonUI(self):
        buttonBox = QHBoxLayout()
        vbox = QHBoxLayout()

        # 카메라 관련 기능
        camGroup = QGroupBox('카메라 관련')

        camGroup.setCheckable(True)
        camGroup.setChecked(True)
        camGroup.resize(10,10)

        self.camBtn = QPushButton('카메라 상태')
        self.camBtn.clicked.connect(self.camOn)
        #self.camBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.callibrationBtn = QPushButton('칼리브레이션')
        self.callibrationBtn.clicked.connect(self.callibrationOn)
        #self.callibrationBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        hbox_cam = QHBoxLayout()
        hbox_cam.addWidget(self.camBtn)
        hbox_cam.addWidget(self.callibrationBtn)
        camGroup.setLayout(hbox_cam)
        vbox.addWidget(camGroup)

        # 저장 관련 기능
        saveGroup = QGroupBox('저장 관련')
        saveGroup.setCheckable(True)
        saveGroup.setChecked(True)
        saveGroup.resize(10, 10)

        self.saveImgBtn = QPushButton('이미지 저장')
        self.saveImgBtn.clicked.connect(self.imageSaveOn)
        #self.saveImgBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.videoBtn = QPushButton('영상 저장')
        self.videoBtn.clicked.connect(self.videoSaveOn)
        #sself.videoBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        hbox_save = QHBoxLayout()
        hbox_save.addWidget(self.saveImgBtn)
        hbox_save.addWidget(self.videoBtn)
        saveGroup.setLayout(hbox_save)
        vbox.addWidget(saveGroup)

        # 포인트 클라우드 관련
        pcGroup = QGroupBox('포인트\n 클라우드')
        pcGroup.setCheckable(True)
        pcGroup.setChecked(True)

        self.pcBtn = QPushButton('포인트\n 클라우드\n 저장')
        self.pcBtn.clicked.connect(self.pointCloudOn)
        self.pcBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        self.pcSendBtn = QPushButton('포인트\n 클라우드\n 전송')
        self.pcSendBtn.clicked.connect(self.pointCloudOn)
        self.pcSendBtn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

        hbox_pc = QHBoxLayout()
        hbox_pc.addWidget(self.pcBtn)
        hbox_pc.addWidget(self.pcSendBtn)
        pcGroup.setLayout(hbox_pc)
        #vbox.addWidget(pcGroup)

        # 뎁스 이미지 관련
        depthGroup = QGroupBox('depth mode')
        depthGroup.setCheckable(True)
        depthGroup.setChecked(False)
        depthGroup.toggled.connect(self.update_stimulus)

        sliderTarget = QLabel('Target range')
        self.Target_slider = QSlider(Qt.Horizontal, self)
        self.Target_slider.move(30, 30)
        self.TargetValueEdit = QLineEdit('0')
        self.Target_slider.setRange(0, 5000)
        self.Target_slider.setSingleStep(50)
        self.Target_slider.valueChanged.connect(self.setTargetValue)

        sliderDepth = QLabel('Depth range')
        self.depth_slider = QSlider(Qt.Horizontal, self)
        self.depth_slider.move(30, 30)
        self.depthValueEdit = QLineEdit('0')
        self.depth_slider.setRange(0, 5000)
        self.depth_slider.setSingleStep(50)
        self.depth_slider.valueChanged.connect(self.setDepthValue)

        hbox_depth = QHBoxLayout()
        hbox_depth.addWidget(sliderTarget)
        hbox_depth.addWidget(self.TargetValueEdit)
        hbox_depth.addWidget(self.Target_slider)
        hbox_depth.addWidget(sliderDepth)
        hbox_depth.addWidget(self.depthValueEdit)
        hbox_depth.addWidget(self.depth_slider)
        depthGroup.setLayout(hbox_depth)
        #vbox.addWidget(depthGroup)

        buttonBox.addLayout(vbox)

        return buttonBox

    def connectSignal(self):
        # camera node slot
        self.nodeL515.dssg.color_signal.connect(self.update_image)
        self.nodeL515.dssg.color_signal2.connect(self.update_image)

    def updateImageLable(self, q_img, cam_No):
        qt_img = self.convert_cv_qt(q_img)
        if cam_No == 1 :
            self.imageLabel.setPixmap(qt_img)
        else :
            self.imageLabel_2.setPixmap(qt_img)


    def convert_cv_qt(self, frame):
        """Convert from an opencv image to QPixmap"""
        rgb_image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        convert_to_Qt_format = QtGui.QImage(rgb_image.data, w, h, bytes_per_line, QtGui.QImage.Format_RGB888)
        p = convert_to_Qt_format.scaled(640, 480, Qt.KeepAspectRatio)
        return QPixmap.fromImage(p)

    def camOn(self):
        pass

    def callibrationOn(self):
        pass

    def imageSaveOn(self):
        if self.nodeL515.img_save_flag :
            self.nodeL515.img_save_flag = False
        else :
            self.nodeL515.img_save_flag = True

    def pointCloudOn(self):
        pass

    def videoSaveOn(self):
        pass

    def setTargetValue(self):
        self.nodeL515.setTargetD(self.Target_slider.value())
        self.TargetValueEdit.setText(str(self.Target_slider.value()))

    def setDepthValue(self):
        self.nodeL515.setThickness(self.depth_slider.value())
        self.depthValueEdit.setText(str(self.depth_slider.value()))

    def update_stimulus(self, checked):
        if not checked:
            self.nodeL515.depth_flag = False
            return
        else :
            self.nodeL515.depth_flag = True

    # image slot for get image
    @pyqtSlot(np.ndarray, int)
    def update_image(self, cv_img, cam_No):
        self.updateImageLable(cv_img, cam_No)


if __name__ == '__main__':
    import sys
    app = QApplication(sys.argv)
    imageViewer = ImageViewer()
    #imageViewer.show()
    sys.exit(app.exec_())

