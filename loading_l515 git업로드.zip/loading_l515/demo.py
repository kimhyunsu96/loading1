import os
import pyrealsense2 as rs
import numpy as np
import cv2

from PyQt5.QtCore import Qt, pyqtSignal, QObject, QThread
from realsense_device_manager import DeviceManager

# Define some constants
L515_resolution_width = 1024  # pixels
L515_resolution_height = 768  # pixels
L515_frame_rate = 30

# Define some constants
resolution_width = 1280  # pixels
resolution_height = 720  # pixels
frame_rate = 30  # fps

dispose_frames_for_stablisation = 30  # frames

def visualise_measurements(frames_devices):
    """
    Calculate the cumulative pointcloud from the multiple devices
    Parameters:
    -----------
    frames_devices : dict
        The frames from the different devices
        keys: str
            Serial number of the device
        values: [frame]
            frame: rs.frame()
                The frameset obtained over the active pipeline from the realsense device
    """
    for (device, frame) in frames_devices.items():
        color_image = np.asarray(frame[rs.stream.color].get_data())
        depth_image = np.asarray(frame[rs.stream.depth].get_data())
        text_str = str(device)
        cv2.putText(color_image, text_str, (50, 50), cv2.FONT_HERSHEY_PLAIN, 2, (0, 255, 0))
        # Visualise the results
        text_str = 'Color image from RealSense Device Nr: ' + str(device)
        cv2.namedWindow(text_str)
        cv2.imshow(text_str, color_image)
        cv2.waitKey(1)

try:
    # Enable the streams from all the intel realsense devices
    L515_rs_config = rs.config()
    L515_rs_config.enable_stream(rs.stream.depth, L515_resolution_width, L515_resolution_height, rs.format.z16,
                                 L515_frame_rate)
    L515_rs_config.enable_stream(rs.stream.infrared, 0, L515_resolution_width, L515_resolution_height,
                                 rs.format.y8,
                                 L515_frame_rate)
    L515_rs_config.enable_stream(rs.stream.color, resolution_width, resolution_height, rs.format.bgr8,
                                 frame_rate)

    rs_config = rs.config()
    rs_config.enable_stream(rs.stream.depth, resolution_width, resolution_height, rs.format.z16, frame_rate)
    rs_config.enable_stream(rs.stream.infrared, 1, resolution_width, resolution_height, rs.format.y8,
                            frame_rate)
    rs_config.enable_stream(rs.stream.color, resolution_width, resolution_height, rs.format.bgr8, frame_rate)

    # Processing blocks
    pc = rs.pointcloud()

    # Use the device manager class to enable the devices and get the frames
    device_manager = DeviceManager(rs.context(), rs_config, L515_rs_config)
    device_manager.enable_all_devices()

    while 1:
        frames = device_manager.poll_frames()
        #visualise_measurements(frames)
        Num_cam = 1

        cam_no1 = {}
        cam_no2 = {}

        for (device, frame) in frames.items():

            pc.map_to(frame[rs.stream.color])
            points = pc.calculate(frame[rs.stream.depth])

            color_image = np.asarray(frame[rs.stream.color].get_data())
            depth_image = np.asarray(frame[rs.stream.depth].get_data())

            if Num_cam == 1:
                cam_no1['color'] = color_image
                cam_no1['depth'] = depth_image
            else:
                cam_no2['color'] = color_image
                cam_no2['depth'] = depth_image


            Num_cam += 1

        images = np.hstack((cam_no1['color'], cam_no2['color']))

        text_str = 'RealSense'
        cv2.namedWindow(text_str)
        cv2.imshow(text_str, images)
        cv2.waitKey(1)


except KeyboardInterrupt:
    print("The program was interupted by the user. Closing the program...")

device_manager.disable_streams()

